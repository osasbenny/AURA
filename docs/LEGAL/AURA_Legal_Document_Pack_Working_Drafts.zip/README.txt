AURA LEGAL DOCUMENT PACK — WORKING DRAFTS
Prepared 18 September 2026

Includes Founders’ Agreement, Shareholders’ Agreement, IP Assignment, Mutual NDA, and Founder Roles & Service Agreement.

These are preliminary drafts, not legal advice and not ready for signature. Complete all placeholders and have a Nigerian lawyer review them against CAC records, the company constitution, applicable law, tax, data protection, IP chain of title, and AURA’s fundraising/payment model.
